# Other projects

Check out other amazing projects brought to you by the [Ploomber](https://ploomber.io/) team!

- [sklearn-evaluation](https://github.com/ploomber/sklearn-evaluation): Plots 📊 for evaluating ML models, experiment tracking, and more!
- [ploomber-engine](https://github.com/ploomber/ploomber-engine): A toolbox 🧰 for executing, testing, debugging, and profiling Jupyter notebooks
- [ploomber](https://github.com/ploomber/ploomber): A framework to build and deploy data pipelines ☁️