# Contributing

For general information, see [Ploombers' contributing guidelines.](https://github.com/ploomber/contributing/blob/main/CONTRIBUTING.md)


For specific JupySQL contributing guidelines, see the [Developer guide](https://jupysql.ploomber.io/en/latest/community/developer-guide.html).
